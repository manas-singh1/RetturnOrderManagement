using NUnit.Framework;
using Payment.Controllers;

namespace PaymentMicroServiceTest
{
    [TestFixture]
    public class PaymentUnitTest
    {
        ProcessPaymentController processPaymentController;
        int result;


        [SetUp]
        public void Setup()
        {
            processPaymentController = new ProcessPaymentController();
            result = 0;
        }

        [TearDown]
        public void TearDown()
        {
            processPaymentController = null;
        }

        [Test]
        public void Test1()
        {
            int expectedResult = 5000;
            result = processPaymentController.ProcessPayment("11112222333344", 20000, 15000);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Test2()
        {
            int expectedResult = 20000;
            result = processPaymentController.ProcessPayment("12345678912345", 30000, 10000);
            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Test3()
        {
            int expectedResult = 15000;
            result = processPaymentController.ProcessPayment("55554444222288", 45000, 30000);
            Assert.AreEqual(expectedResult, result);
        }
    }
}