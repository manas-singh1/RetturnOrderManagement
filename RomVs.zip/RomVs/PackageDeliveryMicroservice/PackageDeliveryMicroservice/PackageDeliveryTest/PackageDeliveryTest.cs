using NUnit.Framework;
using PackageDeliveryMicroservice.Controllers;

namespace PackageDeliveryTest
{
    [TestFixture]
    public class PackageDeliveryTest
    {
        PackagingDeliveryCharge packagingDeliveryCharge;
        int result;

        [SetUp]
        public void Setup()
        {
            packagingDeliveryCharge = new PackagingDeliveryCharge();
            result = 0;
        }
        [TearDown]
        public void TearDown()
        {
            packagingDeliveryCharge = null;
        }

        [Test]
        public void Test1()
        {
            int expectedResult = 600;

            result = packagingDeliveryCharge.GetPackagingDeliveryCharge("integral", 2);

            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Test2()
        {
            int expectedResult = 450;

            result = packagingDeliveryCharge.GetPackagingDeliveryCharge("accessory", 3);

            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Test3()
        {
            int expectedResult = 1500;

            result = packagingDeliveryCharge.GetPackagingDeliveryCharge("integral", 5);

            Assert.AreEqual(expectedResult, result);
        }

        [Test]
        public void Test4()
        {
            int expectedResult = 1050;

            result = packagingDeliveryCharge.GetPackagingDeliveryCharge("accessory", 7);

            Assert.AreEqual(expectedResult, result);
        }
    }
}