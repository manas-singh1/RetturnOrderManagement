﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ComponentProcessing.Models
{
    public static class Price
    {
       
        
        public const int PriorityRepair = 700;
        public const int NoPriorityRepair = 500;
        public const int Replacement = 300;

    }
}
