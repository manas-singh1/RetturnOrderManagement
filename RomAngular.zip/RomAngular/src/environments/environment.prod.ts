export const environment = {
  production: true,

  AuthURL: 'https://localhost:44365/api',
  CompURL: 'https://localhost:44342/api'

};
