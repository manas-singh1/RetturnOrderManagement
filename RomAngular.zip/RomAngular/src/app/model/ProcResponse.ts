export class ProcResponse {
  Id_res: number;
  RequestId: number;
  UserName: string;
  ProcessingCharge: number;
  PackagingAndDeliveryCharge: number;
  DateOfDelivery: string;
  TotalCharge: number;
  CreditCardNo: string;

  constructor(
    Id_res: number,
    RequestId: number,
    UserName: string,
    ProcessingCharge: number,
    PackagingAndDeliveryCharge: number,
    DateOfDelivery: string,
    TotalCharge: number,
    CreditCardNo: string
  ) {
    this.Id_res = Id_res;
    this.RequestId = RequestId;
    this.UserName = UserName;
    this.ProcessingCharge = ProcessingCharge;
    this.PackagingAndDeliveryCharge = PackagingAndDeliveryCharge;
    this.DateOfDelivery = DateOfDelivery;
    this.TotalCharge = TotalCharge;
    this.CreditCardNo = CreditCardNo;
  }
}
