import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfirmResponseComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { ProcessRequestComponent } from './process-request/process-request.component';

const routes: Routes = [
  {path:'process-request',component: ProcessRequestComponent},
  {path:'login',component:LoginComponent},
  {path:'',component:ConfirmResponseComponent},
  {path:'logout',component:LogoutComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
