import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ReqserviceService } from './reqservice.service';
import { Router } from '@angular/router';
import { ProcRequest } from '../model/ProcRequest';
import { ProcResponse } from '../model/ProcResponse';

@Component({
  selector: 'app-process-request',
  templateUrl: './process-request.component.html',
  styleUrls: ['./process-request.component.css'],
})
export class ProcessRequestComponent implements OnInit {
  alert: boolean = false
  requestData: any;
  balanceamt: any;
  requestForm = new FormGroup({
    UserName: new FormControl('', Validators.required),
    ContactNumber: new FormControl('', Validators.required),
    CreditCardNumber: new FormControl('', Validators.required),
    ComponentType: new FormControl('Integral', Validators.required),
    ComponentName: new FormControl('Repair', Validators.required),
    Quantity: new FormControl('', Validators.required),
    PriorityRequest: new FormControl('Y', Validators.required),
  });

  constructor(private service: ReqserviceService, private route: Router) { }

  ngOnInit(): void { }

  onSubmitrequestForm() {
    let procreq = this.requestForm.value;
    let procmodel = new ProcRequest(
      procreq.UserName!,
      procreq.ContactNumber!,
      procreq.CreditCardNumber!,
      procreq.ComponentType!,
      procreq.ComponentName!,
      Number(procreq.Quantity),
      procreq.PriorityRequest!
    );

    this.service.createProcessReqandResponse(procmodel).subscribe(
      (res) => {
        this.requestData = res;
        console.log(res);
        this.requestForm.reset();
      },
      (error) => {
        if (error) {
          this.route.navigate(['login']);
        }
      }
    );
  }
  payment() {

    let respmodel = new ProcResponse(
      this.requestData.id_res,
      this.requestData.requestId,
      this.requestData.userName,
      this.requestData.processingCharge,
      this.requestData.packagingAndDeliveryCharge,
      this.requestData.dateOfDelivery,
      this.requestData.totalCharge,
      this.requestData.creditCardNo
    );

    console.log(this.requestData.id_res);

    this.service.PaymentConfirm(respmodel).subscribe(
      (res) => {
        console.log(res);
        this.balanceamt = res;

        if (res > 0) {
          alert("Your Balance is " + this.balanceamt + " Thank You!!!");
          this.alert = true
        }
        else {
          alert("You have low balance.. Thank You!!!");

        }
      },
      (error) => {
        if (error) {
          this.route.navigate(['login']);
        }
      }
    );

  }

  closeAlert() {
    this.alert = false
  }
}
